# Aprende y Juega

App educativa para niños de 6 a 12 años. Funciona sin internet (excepto "Saber más" en Ciudades y los enlaces de Bibliotecas).

Secciones: juegos educativos (matemática, memoria, países), rompecabezas, retos mentales, taller de dibujo, ciudades del mundo,
historias antiguas (con lectura en voz alta), acertijos, sopa de letras, estudio de audio (grabadora con efectos y piano),
mi mascota y bibliotecas gratis.

- Todo el contenido está en `app/src/main/assets/` (index.html, app.js, data.js). Para agregar acertijos, ciudades o historias, edita `data.js`.
- Los dibujos se guardan en Galería › Pictures/AprendeYJuega y los audios en Música › AprendeYJuega.
- El APK se compila solo en GitHub Actions al subir `AprendeJuega.zip`.
